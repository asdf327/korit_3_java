package assessment.problem1_1;

public class Main {
    public static void main(String[] args) {
        Company company = new Company(
                100, "Apple",
                "Apple Computer Inc. 1 infinite Loop",
                "Cupertion", "CA",
                "95014");

        company.employee();
    }
}
