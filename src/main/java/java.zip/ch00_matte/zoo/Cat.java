package ch00_matte.zoo;

public class Cat extends Animal {
    @Override
    public void speak() {
        System.out.println("야옹");
    }
}
