package ch00_matte.zoo;

public class Animal {
    String name;
    int age;

    public void speak(){
        System.out.println( "동물이 소리를 냅니다.");
    }
}
