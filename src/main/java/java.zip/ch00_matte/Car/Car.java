package ch00_matte.Car;

public class Car implements Vehicle {
    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
