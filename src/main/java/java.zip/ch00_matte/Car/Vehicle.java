package ch00_matte.Car;

public interface Vehicle {
    void start();
    void stop();
}
