package ch00_matte.animal;

public abstract class Animal {
    String name;
    int age;

    public abstract void eat();
}
